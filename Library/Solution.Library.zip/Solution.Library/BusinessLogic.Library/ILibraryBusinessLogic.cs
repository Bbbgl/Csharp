﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Library
{
    public interface ILibraryBusinessLogic
    {
        //User Login(string username, string password);

        //void AddBook(Book book);

        //List<Book> SearchBook(Book book);

        //List<BookViewModel> SearchBookWithAvailabilityInfos(Book book);

        //void UpdateBook(int bookId, Book bookWithNewValues);

        //void DeleteBook(int bookId);

        //User GetUserByUserName(string userName);

        //ReservationResult ReserveBook(int bookId, int userId);

        //ReservationResult BookReturn(int bookId, int userId);

        //List<ReservationViewModel> GetReservationHistory(int? bookId, int? userId, ReservationStatus? reservationStatus);
    }
}
